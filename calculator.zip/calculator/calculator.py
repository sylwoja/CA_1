# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

# Sylwia Wojciechowska
# 10392584

# import math modules for the calculator
import math

# Calculator funcions:

# add two numbers
def add(first, second):
    return first + second

# calculate cosine
def cos(first):
    return math.cos(first)

# divide two numbers
def divide(first, second):
    ''' A message stating can't divide by zero is return if '''
    if second == 0:
        return 'Division by 0 is not allowed'
    return first / second

# exponentiation
def exponent(first, second):
    return first ** second

# calculate factorial
def factorial(first):
    if first == 0:
        return 1
    if first <0:
        return None
    else:
        return first * factorial(first-1)

# muliply two numbers
def multiply(first, second):
     return first * second
    
# calculate sine
def sin(first):
    return math.sin(first)

# calculate square
def square(first):
    return first ** 2

# calculate square root
def squareRoot(first):
    if first == 0:
        return 'invalid input'
    return first **(0.5)

# subtract
def subtract(first, second):
    return first - second


# function to present the menu to the user
def menu():
    print('Welcome to Calculator')
    print('Choose one of the below options:')
    print ('1: Add')
    print ('2: Subtract')
    print ('3: Multiple')
    print ('4: Divide')
    print ('5: Exponent')
    print ('6: Square')
    print ('7: Square Root')
    print ('8: Factorial')
    print ('9: Sine')
    print ('10: Cosine')
    print ('11: Quit')

# display the menu and ask the user to select the operation   
menu()


while True:
    try:
        selection = int(input('Please select the operation 1-11: ' ))
        break
    except:
        print('Make sure you enter a numeric value!')

while selection != 11:
# selection 1 to add two numbers
    if selection == 1: 
        while 1==1:             # validate the number
            try:
                first = float(input('Please enter the first number: '))
                second = float(input('Please enter the second number: '))
                print('result = ', add(first, second))
                break
            except ValueError:
                print('Incorrect input. Please enter numeric value.')
# selection 2 for subtraction 
    elif selection == 2:
        while 1==1:             # validate the number
            try:
                first = float(input('Please enter the first number: '))
                second = float(input('Please enter the second number: '))
                print('result = ', subtract(first, second))
                break
            except ValueError:
                print('Incorrect input. Please enter numeric value.')

# selection 3 for multiplication
        
    elif selection == 3:
        while 1==1:             # validate the number
            try:
                first = float(input('Please enter the first number: '))
                second = float(input('Please enter the second number: '))
                print('result = ', multiply(first, second))
                break
            except ValueError:
                print('Incorrect input. Please enter numeric value.')

 # selection 4 for division       
    elif selection == 4:
        while 1==1:             # validate the number
            try:
                first = float(input('Please enter the first number: '))
                second = float(input('Please enter the second number: '))
                print('result = ', divide(first, second))
                break
            except ValueError:
                print('Incorrect input. Please enter numeric value.')

# selection 5 for exponentiation          
    elif selection == 5:
        while 1==1:             # validate the number
            try:
                first = float(input('Please enter a number: '))
                second = float(input('Please enter the exponent/power: '))
                print('result = ', exponent(first, second))
                break
            except ValueError:
                print('Incorrect input. Please enter numeric value.')
         
# selection 6 for square         
    elif selection == 6:
        while 1==1:             # validate the number
            try:
                first = float(input('Please enter a number to square: '))
                print('result = ', square(first))
                break
            except ValueError:
                print('Incorrect input. Please enter numeric value.')
        
 # selection 7 for square root        
    elif selection == 7:
        while 1==1:             # validate the number
            try:
                first = float(input('Please enter a number: '))
                print('result = ', squareRoot(first))
                break
            except ValueError:
                print('Incorrect input. Please enter numeric value.')

# selection 8 for factorial       
        
    elif selection == 8:
        while 1==1:             # validate the number
            try:
                first = float(input('Please enter a number: '))
                print('result = ', factorial(first))
                break
            except ValueError:
                print('Incorrect input. Please enter numeric value.')

# selection 9 for sine
         
    elif selection == 9:
        while 1==1:             # validate the number
            try:
                first = float(input('Please enter a number: '))
                print('result = ', sin(first))
                break
            except ValueError:
                print('Incorrect input. Please enter numeric value.')

# selection 10 for cosine         
         
    elif selection == 10:
        while 1==1:             # validate the number
            try:
                first = float(input('Please enter a number: '))         
                print('result = ', cos(first))
                break
            except ValueError:
                print('Incorrect input. Please enter numeric value.')
 
        
    else:
        print('Invalid input. Please select the number from 1-11')
    
# display the menu for more operations
    menu()
    while True:
            try:
                selection = int(input('Please select the operation 1-11: ' ))
                break
            except:
                print('Make sure you enter a numeric value!')

   

    

