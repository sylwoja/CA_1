# -*- coding: utf-8 -*-
"""
Created on Tue Sep 11 18:39:23 2018

@author: swojc
"""
 # import the unittest from the Python library
import unittest

from calculator import add, multiply, subtract, divide, exponent, squareRoot, factorial, sin, cos, square
# create a class for the different test cases in Calculator
class CalculatorTest(unittest.TestCase):
    def testAdd(self):
        self.assertEqual(4, add(2, 2))
        self.assertEqual(5, add(5, 0))
        self.assertEqual(1, add(2, -1))
        self.assertEqual(10.5, add(5.5, 5))
        
        
    def testMultiply(self):
        self.assertEqual(4, multiply(2, 2))
        self.assertEqual(5, multiply(5, 1))
        self.assertEqual(30.25, multiply(5.5, 5.5))
        self.assertEqual(-120, multiply(-15, 8))   
        
    def testSubtract(self):
        self.assertEqual(5, subtract(5, 0))
        self.assertEqual(2, subtract(6, 4)) 
        self.assertEqual(6, subtract(-4, -10))
        self.assertEqual(19, subtract(15, -4))
        
    def testDivide(self):
        self.assertEqual(5, divide(10, 2))
        self.assertEqual(2, divide(12, 6))
        self.assertEqual('Division by 0 is not allowed', divide(2, 0))
        self.assertEqual(6, divide(45, 7.5))
    
    def testExponent(self):
        self.assertEqual(32, exponent(2, 5))
        self.assertEqual(1, exponent(2, 0))
        self.assertEqual(-3125, exponent(-5, 5))
        self.assertEqual(2, exponent(4, 0.5))
        self.assertEqual(0.04, exponent(5, -2))
        
    def testSquare(self):
        self.assertEqual(4, square(2))
        self.assertEqual(49, square(-7))
        self.assertEqual(110.25, square(10.5))
        self.assertEqual(0, square(0))
        
    def testSquareRoot(self):
        self.assertEqual(4, squareRoot(16))
        self.assertEqual(8, squareRoot(64))
        self.assertEqual(2.6457513110645907, squareRoot(7))
        self.assertEqual('invalid input', squareRoot(0))
        
    def testFactorial(self):
        self.assertEqual(24, factorial(4))
        self.assertEqual(1, factorial(0))
        self.assertEqual(120, factorial(5))
        self.assertEqual(None, factorial(-5))
        
    def testSin(self):
        self.assertEqual(0.1411200080598672, sin(3))
        self.assertEqual(- 0.1411200080598672, sin(-3))
        self.assertEqual(0.0, sin(0))
        self.assertEqual(0.479425538604203, sin(0.5))
       
        
    def testCos(self):
        self.assertEqual(-0.9899924966004454, cos(3))
        self.assertEqual(-0.6536436208636119, cos(-4))
        self.assertEqual(1.0, cos(0))
        self.assertEqual(0.6216099682706644, cos(0.9))
    
        
unittest.main()